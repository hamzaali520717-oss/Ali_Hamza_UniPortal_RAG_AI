# How to Apply for Admission — Smart University

This guide explains how to apply for undergraduate admission to Smart University, using the BS Computer Science (BSCS) and BS Software Engineering (BSSE) programs offered by the Computer Science Department as examples. Requirements, dates, and fees for other programs are published on each program's page in the university portal; where this guide is silent on a specific program, check that page before applying.

## 1. Eligibility

General eligibility for undergraduate admission at Smart University:

- Completion of Intermediate (FSc/ICS), A-Levels, or an equivalent qualification recognized by the Higher Education Commission.
- No active disciplinary bar from a previously attended institution.
- Meeting the program-specific requirements below.

**BS Computer Science (BSCS):**
- Minimum CGPA of 3.0/4.0 (or equivalent percentage) in intermediate/A-Levels.
- A passing score of 60% or higher on the university's CS entry test.

**BS Software Engineering (BSSE):**
- Minimum CGPA of 2.8/4.0 (or equivalent percentage) in intermediate/A-Levels.
- Submission of a portfolio of prior coding or design projects (personal, academic, or open-source work is acceptable).

Applicants who do not meet the minimum CGPA may still apply but should expect the entry test (BSCS) or portfolio review (BSSE) to weigh more heavily in the admission decision.

## 2. Application Steps

1. **Create a portal account.** Visit the Smart University Portal and register with a valid email address and phone number.
2. **Complete the online application form.** Select your intended program (e.g. BSCS or BSSE) and fill in your personal, academic, and contact details.
3. **Upload required documents** (see Section 3) as scanned PDFs or clear photographs. Incomplete applications are not forwarded for review.
4. **Pay the non-refundable application processing fee** through one of the methods in Section 4. Applications are not considered submitted until payment is confirmed.
5. **Sit the entry test**, if your program requires one (see Section 1). Test dates and centers are announced on the portal after the application deadline closes.
6. **Track your application status** on the portal. You will be notified there — and by email — if additional documents are requested.
7. **Check the merit list** once published (see Section 5 for dates). Merit positions are based on a combination of academic record, entry test score (where applicable), and portfolio review (for BSSE).
8. **Confirm your seat** by paying the first-semester tuition fee (Section 4) within the deadline stated in your admission offer. Seats not confirmed by the deadline may be offered to the next candidate on the merit list.

## 3. Required Documents

- Matriculation and intermediate (or A-Level) certificates and transcripts.
- National ID card (CNIC) or B-Form, and one passport-size photograph.
- Entry test result slip, if applicable to your program.
- Portfolio (BSSE applicants only) — a PDF or link compiling your project work.
- Domicile or equivalent residency certificate, if applying under a regional or reserved seat quota.
- Proof of application fee payment (receipt or transaction ID).

Scanned documents should be legible, in PDF or JPEG format, and under 5 MB per file.

## 4. Fee Payment

Two separate payments are involved in the admission process:

- **Application processing fee:** a small non-refundable fee due at the time of application submission (Section 2, Step 4). This does not count toward tuition.
- **Semester tuition fee:** due after you are offered admission, to confirm your seat. For example, the BS Computer Science program's fee structure is **PKR 85,000 per semester**, broken down as tuition (PKR 70,000), lab charges (PKR 10,000), and library charges (PKR 5,000). Fee structures are set per program and per semester; confirm the exact amount for your program and intended semester on its program page before paying.

Payments can be made via the payment gateway linked from your portal account, or by bank transfer/deposit to the account listed on your fee voucher. Keep your payment receipt — you may be asked to upload or present it during document verification.

If you are unable to pay the full tuition fee, review the scholarships in Section 6 before your seat confirmation deadline; approved scholarships are applied as a credit against the amount due, not as a refund after payment.

## 5. Key Dates (Fall 2026 intake)

| Program | Milestone | Date |
|---|---|---|
| BS Computer Science | Application deadline | August 15, 2026 |
| BS Software Engineering | Application deadline | August 20, 2026 |
| BS Computer Science | Merit list published | September 1, 2026 |

Dates for other programs and intakes are published on the admissions section of the portal as they are finalized. Applications submitted after a program's deadline will not be considered for that intake.

## 6. Scholarships

Smart University offers need- and merit-based financial support to admitted students, including:

- **Merit Scholarship** — a full tuition waiver for students scoring in the top 5% of the entry test, with a minimum CGPA of 3.7.
- **Need-Based Grant** — partial tuition support (up to PKR 50,000) for students demonstrating financial need below the university's declared income threshold.

Scholarship applications are submitted separately from the admission application, after an offer of admission has been made. See the scholarships page on the portal for current eligibility criteria, required documents, and deadlines, as availability and terms can change between intakes.

## 7. Contact

For questions about eligibility, the application process, document requirements, or fee payment, contact the Registrar's Office:

**Email:** registrar@example.edu

Please include your application ID (if you have already registered) in the subject line so the registrar's office can locate your file quickly. Response times are typically 2–3 business days outside of peak application periods.
